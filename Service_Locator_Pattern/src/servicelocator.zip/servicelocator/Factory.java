package servicelocator;

import errors.LocatorError;

public interface Factory {
    Object create(ServiceLocator s1) throws LocatorError;
}
