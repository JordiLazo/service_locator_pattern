package servicelocator;

import errors.LocatorError;
import servicelocator.ServiceLocator;

public interface Factory {
    Object create(ServiceLocator s1) throws LocatorError;
}
